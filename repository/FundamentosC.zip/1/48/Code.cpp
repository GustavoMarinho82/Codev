#include <stdio.h>

long long int fatorial(int N) {
	/* insert your code here */
}

int main() {
	int N;
	
	while (scanf("%d", &N)>0) {
		printf("%lld\n", fatorial(N));
	}
	
	return 0;
}