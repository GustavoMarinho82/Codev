#include <stdio.h>

bool perfeito(int n) {
	/* insert your code here */
}
	
int main(){
	int n;
	
	while (scanf("%d", &n)>0) {
		printf("%d\n", perfeito(n));
	}
	
	return 0;
}