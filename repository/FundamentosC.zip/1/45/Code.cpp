#include <stdio.h>
#include <stdlib.h>

double serie(int N) {
	/* insert your code here */
}
	
int main() {
	int N;
	
	while (scanf("%d", &N)>0) {
		printf("%.16g\n", serie(N));
	}
	
	return 0;
}