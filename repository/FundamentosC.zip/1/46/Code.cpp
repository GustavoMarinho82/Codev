#include <stdio.h>
#include <stdlib.h>

long long int fibonacci(int N) {
	/* insert your code here */
}

int main() {
	int N;
	
	while (scanf("%d", &N)>0) {
		printf("%lld\n", fibonacci(N));
	}
	
	return 0;
}