#include <stdio.h>
#include <stdlib.h>
#include <math.h>



void escrever_seq_fibonacci(int N){
	/* insert your code here */
}

int main(){
	int N;
	
	while (scanf("%d", &N)>0) {
		escrever_seq_fibonacci(N);
	}
	
	return 0;
}