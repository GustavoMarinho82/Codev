#include <stdio.h>

	
int multiplos(int a, int b, int n){
	/* insert your code here */
}

int main() {
	int a, b, n;

	while(scanf("%d", &a)>0) {
		scanf("%d", &b);
		scanf("%d", &n);

		printf("%d\n", multiplos(a, b, n));
	}

	return 0;
}