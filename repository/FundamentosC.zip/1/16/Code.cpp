#include <stdio.h>

int raiz(long long int n) {
	/* insert your code here */
}

int main() {
	long long int n;

	while(scanf("%lld", &n)>0){
		printf("%d\n", raiz(n));
	}

	return 0;
}