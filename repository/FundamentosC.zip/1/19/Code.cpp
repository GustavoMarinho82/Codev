#include <stdio.h>



int mmc(int x, int y) {
	/* insert your code here */
}

int main() {
	int x, y;

	while(scanf("%d", &x)>0){
	    scanf("%d", &y);
	    printf("%d\n", mmc(x, y));
	}

	return 0;
}